package net.wots.item;

import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.wots.block.entity.CynPlushBlockEntity;
import net.wots.item.accessory.PlushieSoundAccessory;

import java.util.*;
import net.wots.util.ShuffledSoundQueue;

public class CynPlushBlockItem extends BlockItem implements PlushieSoundAccessory {

    private final ShuffledSoundQueue soundQueue = new ShuffledSoundQueue(CynPlushBlockEntity.SOUND_DURATIONS);

    public CynPlushBlockItem(Block block, Settings settings) {
        super(block, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.literal("Cyn Plush");
    }

    @Override
    public void playNextPlushieSound(PlayerEntity player) {
        if (player.getWorld().isClient) return;
        SoundEvent sound = soundQueue.tryAdvance(player.getWorld().getTime());
        if (sound != null) {
            player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                    sound, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }
}