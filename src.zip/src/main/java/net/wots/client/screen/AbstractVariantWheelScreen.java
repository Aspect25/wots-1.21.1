package net.wots.client.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;

/**
 * Base class for the radial variant-selection wheel.
 * NVariantWheelScreen and UziVariantWheelScreen were previously 100% identical
 * (~150 lines each) except for the variant type and payload. Now each is ~15 lines.
 */
public abstract class AbstractVariantWheelScreen extends Screen {

    protected final BlockPos targetPos;
    private static final float INNER_R = 38f, OUTER_R = 120f, LABEL_R = 86f, GAP_DEG = 2.5f;
    private int hoveredIndex = -1;

    protected AbstractVariantWheelScreen(BlockPos pos) {
        super(Text.empty());
        this.targetPos = pos;
    }

    protected abstract int variantCount();
    protected abstract String variantDisplayName(int i);
    protected abstract int variantColor(int i);
    protected abstract String variantEnumName(int i);
    protected abstract void sendPayload(BlockPos pos, String variantName, boolean lazyMode);

    @Override public boolean shouldPause()     { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x60000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int cx = width / 2, cy = height / 2, count = variantCount();
        float dx = mouseX - cx, dy = mouseY - cy, distSq = dx * dx + dy * dy;
        float mouseAngle = (float) Math.toDegrees(Math.atan2(dy, dx));
        if (mouseAngle < 0) mouseAngle += 360f;
        float segDeg = 360f / count;
        hoveredIndex = (distSq >= INNER_R * INNER_R && distSq <= OUTER_R * OUTER_R)
                ? (int) (mouseAngle / segDeg) : -1;

        for (int i = 0; i < count; i++) {
            boolean hov = (i == hoveredIndex);
            float oR = hov ? OUTER_R + 8f : OUTER_R;
            int base = variantColor(i);
            int fill = hov ? brighten(base, 55) : darken(base, 15);
            int alpha = hov ? 0xEE : 0xCC;
            drawRing(ctx, cx, cy, INNER_R, oR,
                    i * segDeg + GAP_DEG / 2f, (i + 1) * segDeg - GAP_DEG / 2f, (alpha << 24) | fill);
            float midRad = (float) Math.toRadians(i * segDeg + segDeg / 2f);
            float lR = hov ? LABEL_R + 5f : LABEL_R;
            ctx.drawCenteredTextWithShadow(textRenderer, variantDisplayName(i),
                    cx + (int) (lR * Math.cos(midRad)),
                    cy + (int) (lR * Math.sin(midRad)) - textRenderer.fontHeight / 2,
                    hov ? 0xFFFFFF : 0xDDDDDD);
        }

        drawDisc(ctx, cx, cy, (int) INNER_R, 0xBB1A1A1A);
        boolean hoverCenter = (dx * dx + dy * dy) <= INNER_R * INNER_R;
        ctx.drawCenteredTextWithShadow(textRenderer, "Lazy",
                cx, cy - textRenderer.fontHeight / 2, hoverCenter ? 0xFFFF55 : 0xAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int cx = width / 2, cy = height / 2;
        double dx = mx - cx, dy = my - cy;
        if (dx * dx + dy * dy <= INNER_R * INNER_R) {
            sendPayload(targetPos, "LAZY", true); close(); return true;
        }
        if (button == 0 && hoveredIndex >= 0) {
            sendPayload(targetPos, variantEnumName(hoveredIndex), false); close(); return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    // ── Drawing helpers ───────────────────────────────────────────────────────

    private void drawRing(DrawContext ctx, int cx, int cy, float inner, float outer,
                          float startDeg, float endDeg, int argb) {
        int steps = Math.max(1, (int) (endDeg - startDeg));
        int a = (argb >> 24) & 0xFF, r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();
        VertexConsumer buf = ctx.getVertexConsumers().getBuffer(RenderLayer.getGui());
        for (int s = 0; s < steps; s++) {
            float a1 = (float) Math.toRadians(startDeg + s), a2 = (float) Math.toRadians(startDeg + s + 1);
            float ox1 = cx + outer * (float) Math.cos(a1), oy1 = cy + outer * (float) Math.sin(a1);
            float ox2 = cx + outer * (float) Math.cos(a2), oy2 = cy + outer * (float) Math.sin(a2);
            float ix1 = cx + inner * (float) Math.cos(a1), iy1 = cy + inner * (float) Math.sin(a1);
            float ix2 = cx + inner * (float) Math.cos(a2), iy2 = cy + inner * (float) Math.sin(a2);
            buf.vertex(mat, ox1, oy1, 0).color(r, g, b, a);
            buf.vertex(mat, ox2, oy2, 0).color(r, g, b, a);
            buf.vertex(mat, ix1, iy1, 0).color(r, g, b, a);
            buf.vertex(mat, ox2, oy2, 0).color(r, g, b, a);
            buf.vertex(mat, ix2, iy2, 0).color(r, g, b, a);
            buf.vertex(mat, ix1, iy1, 0).color(r, g, b, a);
        }
    }

    private void drawDisc(DrawContext ctx, int cx, int cy, int radius, int argb) {
        int a = (argb >> 24) & 0xFF, r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();
        VertexConsumer buf = ctx.getVertexConsumers().getBuffer(RenderLayer.getGui());
        for (int s = 0; s < 360; s++) {
            float a1 = (float) Math.toRadians(s), a2 = (float) Math.toRadians(s + 1);
            buf.vertex(mat, cx, cy, 0).color(r, g, b, a);
            buf.vertex(mat, cx + radius * (float) Math.cos(a1), cy + radius * (float) Math.sin(a1), 0).color(r, g, b, a);
            buf.vertex(mat, cx + radius * (float) Math.cos(a2), cy + radius * (float) Math.sin(a2), 0).color(r, g, b, a);
        }
    }

    private static int brighten(int rgb, int amt) {
        return (Math.min(255, ((rgb >> 16) & 0xFF) + amt) << 16)
                | (Math.min(255, ((rgb >> 8) & 0xFF) + amt) << 8)
                | Math.min(255, (rgb & 0xFF) + amt);
    }

    private static int darken(int rgb, int amt) {
        return (Math.max(0, ((rgb >> 16) & 0xFF) - amt) << 16)
                | (Math.max(0, ((rgb >> 8) & 0xFF) - amt) << 8)
                | Math.max(0, (rgb & 0xFF) - amt);
    }
}
