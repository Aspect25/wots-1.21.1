package net.wots.block.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.wots.block.ModBlocks;
import net.wots.block.plushies.cynplush.CynPlushBlock;
import net.wots.sound.ModSounds;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.*;
import net.wots.util.ShuffledSoundQueue;

public class CynPlushBlockEntity extends BlockEntity implements GeoBlockEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // ── Cluster hum constants ─────────────────────────────────────────────────
    /** How often (in ticks) we scan for nearby Cyn plushies. 100 = every 5 sec. */
    private static final int HUM_CHECK_INTERVAL = 100;
    /** Horizontal/vertical radius to scan for sibling Cyns. */
    private static final int HUM_SCAN_RADIUS_H = 6;
    private static final int HUM_SCAN_RADIUS_V = 2;
    /** Minimum cluster size before the hum starts. A lone Cyn is silent. */
    private static final int HUM_MIN_COUNT = 2;

    public static final Map<SoundEvent, Integer> SOUND_DURATIONS = Map.ofEntries(
            Map.entry(ModSounds.CYN_NOISE_1,  40),
            Map.entry(ModSounds.CYN_NOISE_2,  20),
            Map.entry(ModSounds.CYN_NOISE_3,  80),
            Map.entry(ModSounds.CYN_NOISE_4,  80),
            Map.entry(ModSounds.CYN_NOISE_5,  80),
            Map.entry(ModSounds.CYN_NOISE_6,  20),
            Map.entry(ModSounds.CYN_NOISE_7,  60),
            Map.entry(ModSounds.CYN_NOISE_8,  60),
            Map.entry(ModSounds.CYN_NOISE_10, 60)
    );

    private final ShuffledSoundQueue soundQueue;

    public CynPlushBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.CYN_PLUSH_BLOCK_ENTITY, pos, state);
        soundQueue = new ShuffledSoundQueue(SOUND_DURATIONS);
    }

//    // ── Server tick: cluster hum ──────────────────────────────────────────────
//    public static void tick(World world, BlockPos pos, BlockState state, CynPlushBlockEntity be) {
//        if (world.isClient) return;
//        if (world.getTime() % HUM_CHECK_INTERVAL != 0) return;
//
//        // Count nearby Cyn plushies (not counting ourselves).
//        int cynCount = 0;
//        for (int dx = -HUM_SCAN_RADIUS_H; dx <= HUM_SCAN_RADIUS_H; dx++) {
//            for (int dy = -HUM_SCAN_RADIUS_V; dy <= HUM_SCAN_RADIUS_V; dy++) {
//                for (int dz = -HUM_SCAN_RADIUS_H; dz <= HUM_SCAN_RADIUS_H; dz++) {
//                    if (dx == 0 && dy == 0 && dz == 0) continue;
//                    if (world.getBlockState(pos.add(dx, dy, dz)).getBlock() instanceof CynPlushBlock) {
//                        cynCount++;
//                    }
//                }
//            }
//        }
//
//        if (cynCount < HUM_MIN_COUNT) return;
//
//        // Volume scales with cluster size: 2 = quiet, 5+ = loud.
//        // Capped at 1.0 (max vanilla volume). Pitch drops slightly as cluster grows.
//        float volume = Math.min(0.2f + (cynCount - 1) * 0.15f, 1.0f);
//        float pitch  = Math.max(0.9f - (cynCount - 1) * 0.04f, 0.6f);
//
//        world.playSound(null, pos, ModSounds.STATIC, SoundCategory.BLOCKS, volume, pitch);
//    }

    // ── Click sound ───────────────────────────────────────────────────────────
    public void playNextSound() {
        if (world == null || world.isClient) return;
        SoundEvent sound = soundQueue.tryAdvance(world.getTime());
        if (sound != null) world.playSound(null, pos, sound, SoundCategory.BLOCKS, 1.0f, 1.0f);
    }

    public void stopSound() {
        if (world == null || world.isClient) return;
        SoundEvent current = soundQueue.getCurrentlyPlaying();
        if (current == null) return;
        StopSoundS2CPacket packet = new StopSoundS2CPacket(current.getId(), SoundCategory.BLOCKS);
        ((ServerWorld) world).getPlayers(
                player -> player.squaredDistanceTo(Vec3d.ofCenter(pos)) < 64 * 64
        ).forEach(player -> ((ServerPlayerEntity) player).networkHandler.sendPacket(packet));
        soundQueue.clearCurrent();
    }

    // ── GeckoLib ──────────────────────────────────────────────────────────────
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(
                new AnimationController<>(this, "controller", 2, state -> PlayState.STOP)
                        .triggerableAnim("bounce", RawAnimation.begin()
                                .then("squeesh", Animation.LoopType.PLAY_ONCE))
        );
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
